const STORAGE_KEYS = {
  installId: "installId",
  state: "syncState",
};

const DEFAULT_STATE = {
  status: "idle",
  mode: "page",
  username: "",
  sessionId: "",
  uploadToken: "",
  apiBase: "https://api.paidpolitely.com",
  pageUrl: "",
  pagesScanned: 0,
  postsSynced: 0,
  message: "Ready.",
};

let running = false;
let stopRequested = false;
let activeCrawlTabId = null;

chrome.runtime.onInstalled.addListener(async () => {
  await ensureInstallId();
});

chrome.runtime.onMessage.addListener((payload, _sender, sendResponse) => {
  handleMessage(payload).then(sendResponse);
  return true;
});

async function handleMessage(payload) {
  if (payload?.type === "GET_STATE") {
    return getState();
  }

  if (payload?.type === "START_PAGE_CRAWL") {
    const tabId = Number(payload.tabId);
    const pageUrl = String(payload.pageUrl || "");
    const apiBase = String(payload.apiBase || DEFAULT_STATE.apiBase).replace(/\/+$/, "");

    if (!Number.isInteger(tabId) || !isRedditUrl(pageUrl)) {
      return setState({ ...DEFAULT_STATE, status: "error", message: "Open a Reddit page before crawling." });
    }

    stopRequested = false;
    activeCrawlTabId = tabId;

    const state = await setState({
      ...DEFAULT_STATE,
      status: "running",
      mode: "page",
      apiBase,
      pageUrl,
      username: inferUsernameFromUrl(pageUrl) || "",
      message: "Scrolling the current Reddit page...",
    });

    if (!running) {
      runPageCrawl(tabId).catch(async (error) => {
        running = false;
        activeCrawlTabId = null;
        await setState({ status: "error", message: String(error?.message || error) });
      });
    }

    return state;
  }

  if (payload?.type === "STOP_SYNC") {
    stopRequested = true;
    await requestPageCrawlerStop();
    return setState({ status: "idle", message: "Stopping..." });
  }

  return getState();
}

async function runPageCrawl(tabId) {
  running = true;

  try {
    let state = await getState();
    const installId = await ensureInstallId();

    const sessionResponse = await postJson(`${state.apiBase}/api/v1/extension/sessions`, {
      crawlMode: "page",
      redditUsername: state.username || undefined,
      sourceUrl: state.pageUrl,
      extensionInstallId: installId,
      clientVersion: chrome.runtime.getManifest().version,
    });

    state = await setState({
      sessionId: sessionResponse.session.id,
      uploadToken: sessionResponse.uploadToken,
      message: "Session created. Scrolling for lazy-loaded posts...",
    });

    const pageResult = await crawlActivePage(tabId);
    if (stopRequested || pageResult.stopped) {
      await setState({
        status: "idle",
        pagesScanned: pageResult.scrolls,
        message: `Stopped after finding ${pageResult.links.length} post links.`,
      });
      return;
    }

    state = await setState({
      pagesScanned: pageResult.scrolls,
      message: `Found ${pageResult.links.length} post links. Fetching details...`,
    });

    let uploaded = 0;
    const batch = [];

    for (let index = 0; index < pageResult.links.length; index++) {
      if (stopRequested) break;

      const rawPost = await fetchPostFromPermalink(pageResult.links[index]);
      const normalised = normalisePost(rawPost);
      if (normalised) batch.push(normalised);

      if (batch.length >= 25 || (index === pageResult.links.length - 1 && batch.length > 0)) {
        const upload = await uploadBatch(state, batch.splice(0), false);
        uploaded = upload.session.postsReceived;
        state = await setState({
          postsSynced: uploaded,
          message: `Uploaded ${uploaded} posts from ${pageResult.links.length} links...`,
        });
      }

      await wait(250);
    }

    const finalUpload = await uploadBatch(state, [], true);
    await setState({
      status: stopRequested ? "idle" : "completed",
      postsSynced: finalUpload.session.postsReceived,
      message: stopRequested
        ? `Stopped. Synced ${finalUpload.session.postsReceived} posts.`
        : `Completed. Synced ${finalUpload.session.postsReceived} posts.`,
    });
  } finally {
    running = false;
    activeCrawlTabId = null;
  }
}

async function crawlActivePage(tabId) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    func: scrollAndCollectRedditPostLinks,
    args: [{ maxScrolls: 260, stableRounds: 8, waitMs: 1200 }],
  });

  const value = result?.result;
  if (!value || !Array.isArray(value.links)) {
    throw new Error("Could not read post links from the current Reddit page.");
  }

  return value;
}

async function requestPageCrawlerStop() {
  if (!activeCrawlTabId) return;

  await chrome.scripting
    .executeScript({
      target: { tabId: activeCrawlTabId },
      func: () => {
        window.__paidPolitelyStopCrawl = true;
      },
    })
    .catch(() => {});
}

function scrollAndCollectRedditPostLinks(options) {
  const maxScrolls = options?.maxScrolls || 260;
  const stableRoundsTarget = options?.stableRounds || 8;
  const waitMs = options?.waitMs || 1200;
  const seen = new Set();

  window.__paidPolitelyStopCrawl = false;

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function collect() {
    for (const anchor of document.querySelectorAll('a[href*="/comments/"]')) {
      const href = anchor.href || anchor.getAttribute("href") || "";
      const permalink = normalisePostHref(href);
      if (permalink) seen.add(permalink);
    }
  }

  function normalisePostHref(href) {
    try {
      const url = new URL(href, location.href);
      const host = url.hostname.toLowerCase();
      if (!/(^|\.)reddit\.com$/.test(host)) return null;

      const match = url.pathname.match(/\/comments\/([a-z0-9]+)(?:\/[^/]+)?\/?/i);
      if (!match) return null;

      const parts = url.pathname.split("/").filter(Boolean);
      const commentsIndex = parts.findIndex((part) => part.toLowerCase() === "comments");
      const subredditIndex = parts.findIndex((part) => part.toLowerCase() === "r");
      const subreddit = subredditIndex >= 0 ? `/${parts[subredditIndex]}/${parts[subredditIndex + 1]}` : "";
      const slug = parts[commentsIndex + 2] ? `/${parts[commentsIndex + 2]}` : "";
      return `https://www.reddit.com${subreddit}/comments/${match[1]}${slug}/`;
    } catch {
      return null;
    }
  }

  return (async () => {
    let scrolls = 0;
    let stableRounds = 0;
    let previousHeight = 0;
    let previousSeen = 0;

    collect();

    while (scrolls < maxScrolls && stableRounds < stableRoundsTarget && !window.__paidPolitelyStopCrawl) {
      const beforeHeight = document.documentElement.scrollHeight;
      const beforeSeen = seen.size;

      window.scrollTo({ top: beforeHeight, behavior: "auto" });
      await sleep(waitMs);
      window.scrollBy({ top: Math.round(window.innerHeight * 0.9), behavior: "auto" });
      await sleep(waitMs);

      collect();
      scrolls++;

      const afterHeight = document.documentElement.scrollHeight;
      const atBottom = Math.ceil(window.scrollY + window.innerHeight) >= afterHeight - 4;
      const noNewPosts = seen.size === beforeSeen && seen.size === previousSeen;
      const noNewHeight = afterHeight === beforeHeight && afterHeight === previousHeight;

      stableRounds = atBottom && noNewPosts && noNewHeight ? stableRounds + 1 : 0;
      previousHeight = afterHeight;
      previousSeen = seen.size;
    }

    collect();

    return {
      links: [...seen],
      scrolls,
      stopped: Boolean(window.__paidPolitelyStopCrawl),
      reachedEnd: stableRounds >= stableRoundsTarget,
    };
  })();
}

async function fetchPostFromPermalink(permalink) {
  const url = `${permalink.replace(/\/$/, "")}.json?raw_json=1`;
  const response = await fetch(url, {
    credentials: "include",
    headers: { accept: "application/json" },
  });

  if (!response.ok) {
    throw new Error(`Reddit returned ${response.status} for ${permalink}`);
  }

  const listing = await response.json();
  const raw = listing?.[0]?.data?.children?.[0]?.data;
  if (!raw?.id) {
    throw new Error(`Could not parse Reddit post JSON for ${permalink}`);
  }

  return raw;
}

async function uploadBatch(state, posts, completed) {
  return postJson(`${state.apiBase}/api/v1/extension/posts/batch`, {
    sessionId: state.sessionId,
    uploadToken: state.uploadToken,
    posts,
    nextCursor: null,
    completed,
  });
}

function normalisePost(raw) {
  if (!raw?.id || !raw?.name || !raw?.title || !raw?.author || !raw?.created_utc) return null;
  if (raw.author === "[deleted]") return null;

  const permalink = normalisePermalink(raw.permalink || `/comments/${raw.id}`);
  const urls = extractUrls(raw, permalink);

  return {
    id: raw.id,
    name: raw.name,
    subreddit: raw.subreddit || inferSubreddit(permalink) || "",
    title: raw.title,
    selftext: raw.selftext || "",
    author: raw.author,
    link_flair_text: raw.link_flair_text || null,
    score: raw.score || 0,
    upvoteCount: typeof raw.ups === "number" ? raw.ups : null,
    upvote_ratio: typeof raw.upvote_ratio === "number" ? raw.upvote_ratio : null,
    num_comments: raw.num_comments || 0,
    shareCount: typeof raw.share_count === "number" ? raw.share_count : null,
    crosspostCount: raw.num_crossposts || 0,
    mediaUrls: urls.mediaUrls,
    imageUrls: urls.imageUrls,
    outboundUrl: urls.outboundUrl,
    thumbnailUrl: urls.thumbnailUrl,
    permalink,
    created_utc: raw.created_utc,
    rawJson: raw,
  };
}

function extractUrls(raw, permalink) {
  const mediaUrls = new Set();
  const imageUrls = new Set();
  const outboundUrl = normaliseUrl(raw.url_overridden_by_dest || raw.url);
  const thumbnailUrl = normaliseThumbnail(raw.thumbnail);

  addMedia(raw.url_overridden_by_dest || raw.url);
  addMedia(raw.preview?.reddit_video_preview?.fallback_url);
  addMedia(raw.media?.reddit_video?.fallback_url);
  addMedia(raw.secure_media?.reddit_video?.fallback_url);
  addMedia(raw.media?.oembed?.thumbnail_url, true);
  addMedia(raw.secure_media?.oembed?.thumbnail_url, true);

  for (const image of raw.preview?.images || []) {
    addMedia(image.source?.url, true);
    for (const resolution of image.resolutions || []) addMedia(resolution.url, true);
  }

  for (const item of Object.values(raw.media_metadata || {})) {
    addMedia(item?.s?.u || item?.s?.url || item?.s?.gif || item?.s?.mp4, true);
  }

  function addMedia(value, imageHint = false) {
    const url = normaliseUrl(value);
    if (!url) return;
    if (url === permalink) return;
    mediaUrls.add(url);
    if (imageHint || isImageUrl(url)) imageUrls.add(url);
  }

  return {
    mediaUrls: [...mediaUrls],
    imageUrls: [...imageUrls],
    outboundUrl: outboundUrl && outboundUrl !== permalink ? outboundUrl : null,
    thumbnailUrl,
  };
}

function inferSubreddit(permalink) {
  return permalink.match(/\/r\/([^/]+)\//i)?.[1] || null;
}

function normalisePermalink(value) {
  if (/^https?:\/\//i.test(value)) return value;
  return `https://www.reddit.com${value.startsWith("/") ? value : `/${value}`}`;
}

function normaliseUrl(value) {
  if (typeof value !== "string" || !value.trim()) return null;
  const decoded = value.replaceAll("&amp;", "&");
  return /^https?:\/\//i.test(decoded) ? decoded : null;
}

function normaliseThumbnail(value) {
  const ignored = new Set(["default", "self", "nsfw", "spoiler", "image", ""]);
  if (typeof value !== "string" || ignored.has(value)) return null;
  return normaliseUrl(value);
}

function isImageUrl(value) {
  return /\.(?:avif|gif|jpe?g|png|webp)(?:[?#]|$)/i.test(value) || /\/\/(?:i|preview)\.redd\.it\//i.test(value);
}

async function postJson(url, body) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });

  const json = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(json.error || `Request failed with ${response.status}`);
  return json;
}

async function ensureInstallId() {
  const existing = await chrome.storage.local.get(STORAGE_KEYS.installId);
  if (existing.installId) return existing.installId;

  const installId = crypto.randomUUID();
  await chrome.storage.local.set({ [STORAGE_KEYS.installId]: installId });
  return installId;
}

async function getState() {
  const data = await chrome.storage.local.get({ [STORAGE_KEYS.state]: DEFAULT_STATE });
  return data[STORAGE_KEYS.state] || DEFAULT_STATE;
}

async function setState(patch) {
  const current = await getState();
  const next = { ...current, ...patch };
  await chrome.storage.local.set({ [STORAGE_KEYS.state]: next });
  chrome.runtime.sendMessage({ type: "SYNC_STATE", state: next }).catch(() => {});
  return next;
}

function isRedditUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" && /(^|\.)reddit\.com$/i.test(url.hostname);
  } catch {
    return false;
  }
}

function inferUsernameFromUrl(value) {
  try {
    return new URL(value).pathname.match(/\/user\/([^/?#]+)/i)?.[1] || "";
  } catch {
    return "";
  }
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
